# %%
"""
### FIRST, THE GRAPHICAL INTERFACE.
"""

# %%
import sys
if sys.version_info[0] >= 3:
    import PySimpleGUI as sg
else:
    import PySimpleGUI27 as sg
    
import os
import base64
import math
import cmath
import numpy as np
sg.theme('DarkBlack1')

# %%
sys.setrecursionlimit(10**5)

# %%
file_list_column = [
    [
        sg.Text("Browse to choose the folder of the input file:"),
        
    ],
    [
        sg.Text("Input file Folder"), 
        sg.In(size=(30, 6), enable_events=True, key="-FOLDER-"),
        sg.FolderBrowse(),
    ],
    [
        sg.Listbox(
            values=[], enable_events=True, size=(80, 40), key="-FILE LIST-"
        )
    ],
]
layout = [
    [
        sg.Column(file_list_column),
    ]
]

# %%
window = sg.Window("File Browser", layout, size=(520,470))

# %%
while True:
    event, values = window.read()
    if event == "Exit" or event == sg.WIN_CLOSED:
        break
    if event == "-FOLDER-":
        folder = values["-FOLDER-"]
        try:
            # Get list of files in folder
            file_list = os.listdir(folder)
        except:
            file_list = []

        fnames = [
            f
            for f in file_list
            if os.path.isfile(os.path.join(folder, f))
            and f.lower().endswith((".txt"))
        ]
        window["-FILE LIST-"].update(fnames)
    elif event == "-FILE LIST-":  # A file was chosen from the listbox
        try:
            filename = os.path.join(
                values["-FOLDER-"], values["-FILE LIST-"][0]
            )
            input_file = open(filename, 'r')
            Lines = input_file.readlines()
            window.close()
        except:
            pass

# %%
"""
### DETECTING ALL THE COMPONENTS FROM THE INPUT FILE, CREATING A LIST OF DICRTIONARIES FOR EACH TYPE.
"""

# %%
L = []
for line in Lines:
    L = L + [line.strip('\n').strip('\t').split(" ")]

vcvs = [] # All of the voltage controlled voltage sources
ccvs = [] # All of the current controlled voltage sources
vsrc = [] # All of the independent voltage sources 

R = [] # All of the resistances
cap = [] # All of the capacitors 
ind = [] # All of the inductors

isrc = [] # All of the independent current sources
cccs = [] # All of the current controlled current sources
vccs = [] # All of the voltage controlled current sources

for i in range(len(L)):
    if (L[i][0] == "res"):
        R += [{
            "name": L[i][1],
            "node1": L[i][2],
            "node2": L[i][3],
            "value": float(L[i][4]),
            "type": "res"
        }]
    elif (L[i][0] == "cap"):
        cap += [{
            "name": L[i][1],
            "node1": L[i][2],
            "node2": L[i][3],
            "value": float(L[i][4]),
            "type": "cap"
        }]
    elif (L[i][0] == "ind"):
        ind += [{
            "name": L[i][1],
            "node1": L[i][2],
            "node2": L[i][3],
            "value": float(L[i][4]),
            "type": "ind"
        }]
        
        
        
    ## INDEPENDET VOLTAGE AND CURRENT SOURCES
    elif (L[i][0] == "vsrc"):
        vsrc += [{
            "name": L[i][1],
            "node1": L[i][2], # positive terminal
            "node2": L[i][3], # negative terminal
            "value": float(L[i][4]),
            "phase": float(L[i][5]),
            "type": "vsrc"
        }]
        
    elif (L[i][0] == "isrc"):
        isrc += [{
            "name": L[i][1],
            "node1": L[i][2], # head of the arrow
            "node2": L[i][3], # tail of the arrow
            "value": float(L[i][4]),
            "phase": float(L[i][5]),
            "type": "isrc"
        }]
        
        
        
    ### DEPENDENT VOLTAGE SOURCE
    elif (L[i][0] == "vcvs"):
        vcvs += [{
            "name": L[i][1],
            "node1": L[i][2], # positive terminal
            "node2": L[i][3], # negative terminal
            "d_node1": L[i][4], # positive terminal of the source it is dependent on 
            "d_node2":  L[i][5], # negative terminal of the source it is dependent on 
            "coefficient": L[i][6],
            "value": 0, # to be set later !
            "type": "vcvs"
        }]
    elif (L[i][0] == "ccvs"):
        ccvs += [{
            "name": L[i][1],
            "node1": L[i][2], # positive terminal
            "node2": L[i][3], # negative terminal
            "d_node1": L[i][4], # tail of the arrow of the current source it is dependent on
            "d_node2":  L[i][5], # head of the arrow of the current source it is dependent on
            "resistance": L[i][6],
            "coefficient": L[i][7],
            "value": 0, # to be set later !
            "type": "ccvs"
        }]
        
    ### DEPENDENT CURRENT SOURCES
    elif (L[i][0] == "cccs"):
        cccs += [{
        "name": L[i][1],
        "node1": L[i][2], # head of the arrow
        "node2": L[i][3], # tail of the arrow
        "d_node1": L[i][4], # tail of the arrow of the current source it is dependent on 
        "d_node2":  L[i][5], # head of the arrow of the current source it is dependent on
        "resistance": L[i][6],
        "coefficient": L[i][7],
        "value": 0, # to be set later !
        "type": "cccs"
    }]
    elif (L[i][0] == "vccs"):
        vccs += [{
        "name": L[i][1],
        "node1": L[i][2], # head of the arrow
        "node2": L[i][3], # tail of the arrow
        "d_node1": L[i][4], # positive terminal of the voltage source it is dependent on 
        "d_node2":  L[i][5], # negative terminal of the voltage source it is dependent on 
        "coefficient": L[i][6],
        "value": 0, # to be set later !
        "type": "vccs"
    }]
    
    
    
    ## Setting the angular frequency!
    elif(L[i][0] == "w"):
        w = float(L[i][1]) 
    
    # Setting the ground node.
    elif(L[i][0] == "ground"):
        ground_node = int(L[i][1])

ALL_LISTS = [vcvs, ccvs, vsrc, isrc, cccs, vccs, R, cap, ind]
nodes = []

# %%
"""
### Now, generating the list of (not unique) nodes
"""

# %%
for List in ALL_LISTS:
    for dictionary in List:
        nodes.append(int(dictionary["node1"]))
        nodes.append(int(dictionary["node2"]))

# %%
"""
### Now, generating the list of unique nodes, and a list of complex nodes, and a list of the number of occurrences for each complex nodes. The number of occurences signifies the number of branches connected with each complex node.
"""

# %%
Set = set(); uniq_nodes = []; 
uniq_nodes = [node for node in nodes if node not in Set and not Set.add(node)]
num_of_occ = [0] * len(uniq_nodes)
complex_nodes = []

for i in range(len(uniq_nodes)):
    for node in nodes:
        if (uniq_nodes[i] == node):
            num_of_occ[i] += 1
            
for i in range(len(uniq_nodes)):
    if (num_of_occ[i] > 2):
        complex_nodes.append(uniq_nodes[i])
        
simple_nodes = [node for node in uniq_nodes if node not in complex_nodes]

# %%
"""
### Arranging complex nodes, simple nodes in order
"""

# %%
def bubbleSort(arr): 
    n = len(arr) 
  
    # Traverse through all array elements 
    for i in range(n-1): 
    # range(n) also work but outer loop will repeat one time more than needed. 
  
        # Last i elements are already in place 
        for j in range(0, n-i-1): 
  
            # traverse the array from 0 to n-i-1 
            # Swap if the element found is greater 
            # than the next element 
            if arr[j] > arr[j+1] : 
                arr[j], arr[j+1] = arr[j+1], arr[j] 

# %%
bubbleSort(complex_nodes)
bubbleSort(simple_nodes)
bubbleSort(uniq_nodes)

# %%
"""
### Setting Xc, Xl and R values with the appropriate units, assuming they are Mf, mH, kOhm respectively.
"""

# %%
for capacitor in cap:
    capacitor["Xc"] = (1 / (w * capacitor["value"])) * (10 ** 6)

for inductor in ind:
    inductor["Xl"] = (w * inductor["value"]) * (10 ** -3)

for resistance in R:
    resistance["value"] *= 1000

# %%
for c in cap:
    c["z"] = complex(c["Xc"] * math.cos(3 * math.pi / 2), c["Xc"] * math.sin(3 * math . pi / 2))
for r in R:
    r["z"] = complex(r["value"] * math.cos(0), r["value"] * math.sin(0))
for i in ind:
    i["z"] = complex(i["Xl"] * math.cos(math.pi / 2), i["Xl"] * math.sin(math . pi / 2))

# %%
"""
### Solving the circuit in case there are no complex nodes.
"""

# %%
def Find_simple_version(n, List, reference):
    
    to_return = complex(0, 0)
    
    for component in List:
        
        if((int(component["node1"]) == n) & (component != reference)):
            to_return = to_return + complex(component["value"] * math.cos(component["phase"] * math.pi / 180), component["value"] * math.sin(component["phase"] * math.pi / 180))
            
        elif((int(component["node1"] == n)) & (component != reference)):
            to_return = to_return +  (-1) * complex(component["value"] * math.cos(component["phase"] * math.pi / 180), component["value"] * math.sin(component["phase"] * math.pi / 180))
    
    return complex(to_return.imag, to_return.real)

# %%
if not complex_nodes:
    Z_ALL = complex(0, 0)
    V_ALL = complex(0, 0)
    I_ALL = complex(0, 0)
    v_for_simple_nodes0 = {}
    
    for List in [cap, R, ind]:
        for item in List:
            Z_ALL += item["z"]
    
    if vsrc:
        v_reference = vsrc[0]
        v_else = Find_simple_version(int(v_reference["node2"]), vsrc, v_reference)        
        
        V_ALL = v_else + complex(v_reference["value"] * math.cos(v_reference["phase"] * math.pi / 180), v_reference["value"] * math.sin(v_reference["phase"] * math.pi / 180))
        I_ALL = V_ALL / Z_ALL        
    
        v_for_simple_nodes0[int(v_reference["node1"])] = complex(v_reference["value"] * math.cos(v_reference["phase"] * math.pi / 180), v_reference["value"] * math.sin(v_reference["phase"] * math.pi / 180))
        
        for List in [R, cap, ind]:
            for component in List:
                if (int(component["node1"]) == int(v_reference["node1"])):
                    
                    v_for_simple_nodes0[int(component["node2"])] = V_ALL - (I_ALL * component["z"])
                    
                elif (int(component["node2"]) == int(v_reference["node1"])):
                    
                    v_for_simple_nodes0[int(component["node1"])] = V_ALL - (I_ALL * component["z"])
        
        
        for List in [R, cap, ind]:
            for component in List:
                
                if ((int(component["node1"]) in list(v_for_simple_nodes0.keys())) &  (int(component["node2"]) not in list(v_for_simple_nodes0.keys()))):
                    
                    v_for_simple_nodes0[int(component["node2"])] = v_for_simple_nodes0[int(component["node1"])] - I_ALL * component["z"]
                
                elif((int(component["node2"]) in list(v_for_simple_nodes0.keys())) &  (int(component["node2"]) not in list(v_for_simple_nodes0.keys()))):
                    
                    v_for_simple_nodes0[int(component["node1"])] = v_for_simple_nodes0[int(component["node2"])] - I_ALL * component["z"]
    
    elif isrc:
        i_reference = isrc[0]
        I_ALL = Find_simple_version(int(i_reference["node2"]), isrc, i_reference) + complex(i_reference["value"] * math.cos(i_reference["phase"] * math.pi / 180), i_reference["value"] * math.sin(i_reference["phase"] * math.pi / 180))
        
    
    for key, value in v_for_simple_nodes0.items():
        print("The volt at node", key, "=", value, '\n')

# %%
"""
### Setting the searched member of all components to false for the next function
"""

# %%
for List in ALL_LISTS:
    for component in List:
        component["searched"] = False

# %%
"""
### A recursive function to find all the components in each branch of the branches connected to each complex node
"""

# %%
def Find(n):
    templist = []
    for List in ALL_LISTS:
        
        if not List:
            continue
        
        for component in List:
            
            if (int(component["node1"]) == n):
                
                if (int(component["node2"]) in complex_nodes):
                    if (component["searched"] == False):
                        templist.append(component)
                        component["searched"] = True
                        return templist
                    else:
                        continue
                
                else:
                    if(component["searched"] == False):
                        templist.append(component)
                        component["searched"] = True
                        templist2 = Find(int(component["node2"]))
                        for x in templist2:
                            templist.append(x)
                        return templist
                    else:
                        continue
                
            elif (int(component["node2"]) == n):
                if (int(component["node1"]) in complex_nodes):
                    if (component["searched"] == False):
                        templist.append(component)
                        component["searched"] = True
                        return templist
                    else:
                        continue
                
                else:
                    if (component["searched"] == False):
                        templist.append(component)
                        component["searched"] = True
                        templist2 = Find(int(component["node1"]))
                        for x in templist2:
                            templist.append(x)
                        return templist
                    else:
                        continue

# %%
"""
### Applying the function to each complex node, and optaining a list for each one.
"""

# %%
list_for_all_cmplx = []
for node in complex_nodes:
    # setting searched member to False for the current iteration of nodes!
    spec_list = []
    
    for List in ALL_LISTS:
        for component in List:
            component["searched"] = False
            
    for num in num_of_occ:
        for i in range(num):
            temp = Find(node)
            if (temp != None):
                spec_list.append(temp)
    list_for_all_cmplx.append(spec_list)

# %%
"""
### Determining the complex node to which each branch of each complex node is connected. 
"""

# %%
listofdicts_for_all_cmplx = []

for i in range(len(complex_nodes)):
    
    templist = []
    
    for List in list_for_all_cmplx[i]:
        
        #print(List, '\n\n')
        
        if (len(List) == 1):
            if (int(List[0]["node1"]) == complex_nodes[i]):
                tempdict = {int(List[0]["node2"]) : List}
                templist.append(tempdict)
            else:
                tempdict = {int(List[0]["node1"]) : List}
                templist.append(tempdict)
                
        else:
            if (int(List[-1]["node1"]) in complex_nodes):
                tempdict = {int(List[len(List) - 1]["node1"]) : List}
                templist.append(tempdict)
            else:
                tempdict = {int(List[-1]["node2"]) : List}
                templist.append(tempdict)
                
    listofdicts_for_all_cmplx.append(templist)

# %%
"""
### For removing the item 'searched' after finishing detecting components.
"""

# %%
for List in ALL_LISTS:
    for component in List:
        component.pop("searched", None)

# %%
"""
### Calculating Z for each branch
"""

# %%
# looping over nodes
for i in range(len(listofdicts_for_all_cmplx)):
    
    # looping over branches (they are dictionaries!)
    for j in range(len(listofdicts_for_all_cmplx[i])):
        
        temp_z = complex(0, 0)
        
        for component in list(listofdicts_for_all_cmplx[i][j].values())[0]:
            
            if (component["type"] == "res"):
                temp_res =  complex(component["value"] * math.cos(0), component["value"] * math.sin(0))
                temp_z += temp_res
                
            if (component["type"] == "cap"):
                temp_cap =  complex(component["Xc"] * math.cos((3*math.pi) / 2), component["Xc"] * math.sin((3*math.pi) / 2))
                temp_z += temp_cap
                
            if (component["type"] == "ind"):
                temp_ind = complex(component["Xl"] * math.cos(math.pi / 2), component["Xl"] * math.sin(math.pi/2))
                temp_z += temp_ind
        
        listofdicts_for_all_cmplx[i][j]["Z"] = math.sqrt(temp_z.real ** 2 + temp_z.imag ** 2)
        listofdicts_for_all_cmplx[i][j]["Z-Imaginary"] = temp_z
        
        try:
            listofdicts_for_all_cmplx[i][j]["Z-theta"] = math.atan(temp_z.imag / temp_z.real)
            
        except ZeroDivisionError:
            
            if ((temp_z.real == 0) & (temp_z.imag < 0)):
                listofdicts_for_all_cmplx[i][j]["Z-theta"] = -1 * (math.pi / 2)

            elif ((temp_z.real == 0) & (temp_z.imag > 0)):
                listofdicts_for_all_cmplx[i][j]["Z-theta"] = math.pi / 2
                
            elif ((temp_z.real == 0) & (temp_z.imag == 0)):
                listofdicts_for_all_cmplx[i][j]["Z-theta"] = 0

# %%
"""
### Printing the results.
"""

# %%
""""
for i in range(len(listofdicts_for_all_cmplx)):
    
    print("The branches connected to node", complex_nodes[i],':\n')
    
    for j in range(len(listofdicts_for_all_cmplx[i])):
        print(listofdicts_for_all_cmplx[i][j], '\n')
    print('\n\n')
"""

# %%
"""
### Obtaining the Conductance Matrix.
"""

# %%
conductance_array = []
for i in range(len(complex_nodes)):
    
    tempRowArray = [0] * len(complex_nodes)
    
    ## THE FOLLOWING IS FOR THE CASE THAT THERE ARE TWO NODES CONNECTED THROUGH MORE THAN ONE BRANCH.
    tempDict = {}
    for t in complex_nodes:
        if (t != complex_nodes[i]):
            tempDict[t] = 0
    
    for key in tempDict.keys():
        for k in range(len(listofdicts_for_all_cmplx[i])):
            if (key == list(listofdicts_for_all_cmplx[i][k].keys())[0]):
                tempDict[key] += 1
    ########################
    
    parallel_branches = False
    
    for x in tempDict.values():
        if (x > 1):
            parallel_branches = True
            
    
    # Calculating the other elements.
    if (parallel_branches):
        
        
        for k in range(len(listofdicts_for_all_cmplx[i])):
            z_equivalent = complex(0, 0)
            if (tempDict[list(listofdicts_for_all_cmplx[i][k].keys())[0]] > 1):

                z = []

                for x in range(len(listofdicts_for_all_cmplx[i])):
                    if list(listofdicts_for_all_cmplx[i][k].keys())[0] == list(listofdicts_for_all_cmplx[i][x].keys())[0]:
                        z.append(listofdicts_for_all_cmplx[i][x]["Z-Imaginary"])
                
                # Calculating z equivalent.     
                for x in z:
                    if (x != complex(0, 0)):
                        z_equivalent += (1 / x)
                z_equivalent = z_equivalent ** -1
                
                tempRowArray[list(listofdicts_for_all_cmplx[i][k].keys())[0] - 1] = -1 / z_equivalent
                                
                tempDict[list(listofdicts_for_all_cmplx[i][k].keys())[0]] -= len(z)



            elif (tempDict[list(listofdicts_for_all_cmplx[i][k].keys())[0]] == 1):

                z_for_this_branch = listofdicts_for_all_cmplx[i][k]["Z-Imaginary"]
                
                if (z_for_this_branch == complex(0, 0)):
                    conductance_for_this_branch = complex(0, 0)
                else:
                    conductance_for_this_branch = -1 / z_for_this_branch
                tempRowArray[list(listofdicts_for_all_cmplx[i][k].keys())[0] - 1] = conductance_for_this_branch

                tempDict[list(listofdicts_for_all_cmplx[i][k].keys())[0]] -= 1

            else:
                continue
        
        # Calculating the main diagonal element.
        main_dia_conductance = complex(0, 0)
        for x in range(len(complex_nodes)):
            if (x != i):
                main_dia_conductance += -1 * tempRowArray[x]
        
        tempRowArray[i] = main_dia_conductance 
        
        
                
    else:
        
        tempRowArray = [0] * len(complex_nodes)
    
        # Calculating the main diagonal element.
        all_conductance_for_this_node = complex(0, 0)
    
        for k in range(len(listofdicts_for_all_cmplx[i])):
            if (listofdicts_for_all_cmplx[i][k]["Z-Imaginary"] != complex(0,0)):
                all_conductance_for_this_node += 1 / listofdicts_for_all_cmplx[i][k]["Z-Imaginary"]
        tempRowArray[i] = all_conductance_for_this_node
    
        # Calculating the other elements.
        for k in range(len(listofdicts_for_all_cmplx[i])):
            z_for_this_branch = listofdicts_for_all_cmplx[i][k]["Z-Imaginary"]
        
            if (z_for_this_branch == complex(0, 0)):
                conductance_for_this_branch = complex(0, 0)
            else:
                conductance_for_this_branch = -1 / z_for_this_branch
            tempRowArray[list(listofdicts_for_all_cmplx[i][k].keys())[0] - 1] = conductance_for_this_branch
    
    conductance_array.append(tempRowArray)

# %%
"""
### CHECKING WHETHER SUPER NODES EXIST.
"""

# %%
super_nodes = []
for i in range(len(listofdicts_for_all_cmplx)):
    
    for k in range(len(listofdicts_for_all_cmplx[i])):
            
            all_vsrc = True
            
            for x in list(listofdicts_for_all_cmplx[i][k].values())[0]:
                if x["type"] != "vsrc":
                    all_vsrc = False
                    
            if (all_vsrc == True):
                
                temp_tuple = (list(listofdicts_for_all_cmplx[i][k].keys())[0], complex_nodes[i])
                temp_tuple2 = (temp_tuple[1], temp_tuple[0])
                
                if ((temp_tuple not in super_nodes) & (temp_tuple2 not in super_nodes)):
                    super_nodes.append(temp_tuple)

# %%
"""
### Changing the conductance matrix if super nodes exists accordingly.
"""

# %%
v_super_list = []
for pair in super_nodes:
    
    # Working on the node with the smallest index in the array. With name super
    Super = pair[0] if pair[0] < pair[1] else pair[1]
    Other = pair[1] if Super == pair[0] else pair[0]
    
    
    for k in range(len(conductance_array[Other - 1])):
        conductance_array[Other - 1][k] += conductance_array[Super -1][k]
    
    conductance_array[Super - 1] = [0] * len(complex_nodes)
    
    conductance_array[Super - 1][Super - 1] = 1
    conductance_array[Super - 1][Other - 1] = -1
    
    for k in range(len(listofdicts_for_all_cmplx[Super - 1])):
        if (list(listofdicts_for_all_cmplx[Super - 1][k].keys())[0] == Other):
            
            flag = True
            
            for x in (list(listofdicts_for_all_cmplx[Super - 1][k].values())[0]):
                if x["type"] != "vsrc":
                    flag = False
            if flag:
                v_super = complex(0, 0)
                for x in (list(listofdicts_for_all_cmplx[Super - 1][k].values())[0]):
                    if (int(x["node1"]) == Super):
                        v_super += complex(x["value"] * math.cos((x["phase"] * math.pi) / 180), x["value"] * math.sin((x["phase"] * math.pi) / 180))
                    else: 
                        print(v_super)
                        v_super += -1 * complex(x["value"] * math.cos((x["phase"] * math.pi) / 180), x["value"] * math.sin((x["phase"] * math.pi) / 180))
                        print(v_super)
                v_super_list.append({Super: v_super})

# %%
"""
### Obtaining the absolute terms matrix.
"""

# %%
B = [0] * len(complex_nodes)


# Looping over every complex node
for i in range(len(listofdicts_for_all_cmplx)):
    b = complex(0,0)
    # Looping over every branch connected to it.
    for k in range(len(listofdicts_for_all_cmplx[i])):
        
        # looping over the components in the branch
        for x in list(listofdicts_for_all_cmplx[i][k].values())[0]:
                        
            # For current sources.
            if x["type"] == "isrc":
                if (int(x["node1"]) in complex_nodes):
                    if(int(x["node1"]) == complex_nodes[i]):
                        b += complex(x["value"] * math.cos((x["phase"] / 180) * math.pi), x["value"] * math.sin((x["phase"] / 180) * math.pi))
                    else:
                        b += -1 * complex(x["value"] * math.cos((x["phase"] / 180) * math.pi), x["value"] * math.sin((x["phase"] / 180) * math.pi))
                        
                        
                elif (int(x["node2"]) in complex_nodes):
                    if(int(x["node2"]) == complex_nodes[i]):
                        b += -1 * complex(x["value"] * math.cos((x["phase"] / 180) * math.pi), x["value"] * math.sin((x["phase"] / 180) * math.pi))
                    else:
                        b += complex(x["value"] * math.cos((x["phase"] / 180) * math.pi), x["value"] * math.sin((x["phase"] / 180) * math.pi))
    
            # For voltage sources
            if x["type"] == "vsrc":
                if (int(x["node1"]) in complex_nodes):
                    if(int(x["node1"]) == complex_nodes[i]):
                    
                        if (listofdicts_for_all_cmplx[i][k]["Z-Imaginary"] == complex(0, 0)):
                            b += complex(0, 0)
                        else:
                            b += complex(x["value"] * math.cos((x["phase"] / 180) * math.pi), x["value"] * math.sin((x["phase"] / 180) * math.pi))  / (listofdicts_for_all_cmplx[i][k]["Z-Imaginary"])
                    else:
                        if (listofdicts_for_all_cmplx[i][k]["Z-Imaginary"] == complex(0, 0)):
                            b += complex(0, 0)
                        else:
                            b += -1 * complex(x["value"] * math.cos((x["phase"] / 180) * math.pi), x["value"] * math.sin((x["phase"] / 180) * math.pi))  / (listofdicts_for_all_cmplx[i][k]["Z-Imaginary"])
                        
                        
                elif (int(x["node2"]) in complex_nodes):
                    if(int(x["node2"]) == complex_nodes[i]):
                        if (listofdicts_for_all_cmplx[i][k]["Z-Imaginary"] == complex(0, 0)):
                            b += complex(0, 0)
                        else:
                            b += -1 * complex(x["value"] * math.cos((x["phase"] / 180) * math.pi), x["value"] * math.sin((x["phase"] / 180) * math.pi))  / (listofdicts_for_all_cmplx[i][k]["Z-Imaginary"])
                    else:
                        if (listofdicts_for_all_cmplx[i][k]["Z-Imaginary"] == complex(0, 0)):
                            b += complex(0, 0)
                        else:
                            b += complex(x["value"] * math.cos((x["phase"] / 180) * math.pi), x["value"] * math.sin((x["phase"] / 180) * math.pi))  / (listofdicts_for_all_cmplx[i][k]["Z-Imaginary"])
    B[complex_nodes[i] - 1] = b

# %%
"""
### Changing the absolute term matrix if super nodes exists accordingly.
"""

# %%
for pair in super_nodes:
    Other = pair[0] if pair[0] > pair[1] else pair[1]
    Super = pair[1] if pair[0] > pair[1] else pair[0]
    
    B[Other - 1] += B[Super - 1]
    for x in v_super_list:
        if (list(x.keys())[0] == Super):
            B[Super - 1] = list(x.values())[0]

# %%
"""
### Removing the column and rows corresponding to the ground node, if it is a complex node.
"""

# %%
if (ground_node in complex_nodes):
    index_of_ground = complex_nodes.index(ground_node)
    
    del conductance_array[index_of_ground]
    
    for i in range(len(conductance_array)):
        del conductance_array[i][index_of_ground]
    
    del B[index_of_ground]

# %%
"""for i in range(len(conductance_array)):
    print(conductance_array[i])

print('\n' ,B)
"""

# %%
"""for i in range(len(listofdicts_for_all_cmplx)):
    for k in range(len(listofdicts_for_all_cmplx[i])):
        
        for x in list(listofdicts_for_all_cmplx[i][k].values())[0]:
            if (x["type"] == "ccvs"):
                
                if (int(x["d_node1"]) in complex_nodes & int(x["d_node2"]) in complex_nodes):
                    
                    dnode1co = x["coefficient"] / 
                    
                    x["value"] = 0
                    
                    
                    
"""                    

# %%
"""
### Solving the system of equations.
"""

# %%
v_for_complex_nodes = [0] * len(complex_nodes)

# %%
if conductance_array:
    x = np.linalg.solve(conductance_array, B)

# %%
for i in range(len(complex_nodes)):
    if (complex_nodes[i] != ground_node):
        v_for_complex_nodes[i] = list(x).pop(i)
    
    print("The voltage at node", complex_nodes[i], "=" ,round(v_for_complex_nodes[i], 3))

# %%
"""
### FINDING THE VOLTAGES AT SIMPLE NODES.
"""

# %%
# Looping over nodes.
v_for_simple_nodes = {}

for i in range(len(listofdicts_for_all_cmplx)):
    # Looping over branches
        for k in range(len(listofdicts_for_all_cmplx[i])):
            
            # if there is a simple node or more between them.
            if len(list(listofdicts_for_all_cmplx[i][k].values())[0]) > 1:
                
                current = complex(0, 0)
                # working only on those branches that are arranged well, the other ones, the corresponding ones, we may ignore.
                if (int(list(listofdicts_for_all_cmplx[i][k].values())[0][-1]["node2"]) in complex_nodes):
                                        
                    thereIsVs = False
                    for x in list(listofdicts_for_all_cmplx[i][k].values())[0]:
                        if (x["type"] == "vsrc"):
                            thereIsVs = True
                    
                    # In case there is a voltage source
                    if (thereIsVs):
                        
                        # For the voltage sources
                        for x in list(listofdicts_for_all_cmplx[i][k].values())[0]:
                            
                            if (x["type"] == "vsrc"):
                                if ((int(x["node1"]) in simple_nodes) & (int(x["node2"]) in complex_nodes)):
                                    v_for_simple_nodes[int(x["node1"])] =  complex(x["value"] * math.cos(x["phase"] * math.pi / 180), x["value"] * math.sin(x["phase"] * math.pi / 180)) + v_for_complex_nodes[int(x["node2"]) - 1]
                                
                                elif ((int(x["node2"]) in simple_nodes) & (int(x["node1"]) in complex_nodes)):
                                    v_for_simple_nodes[int(x["node2"])] = -1 * complex(x["value"] * math.cos(x["phase"] * math.pi / 180), x["value"] * math.sin(x["phase"] * math.pi / 180)) + v_for_complex_nodes[int(x["node1"]) - 1]
                        
                        # For the other components
                        for x in list(listofdicts_for_all_cmplx[i][k].values())[0]:
                            
                            if (x["type"] != "vsrc"):
                                
                                # In case the component is at the beginning of the branch.
                                if (int(x["node1"]) in complex_nodes):
                                    
                                    if ((x["type"] == "res") | (x["type"] == "cap") | (x["type"] == "ind")):
                                        
                                        if ( int(x["node2"]) not in list(v_for_simple_nodes.keys()) ):
                                            
                                            current = (v_for_complex_nodes[int(x["node1"]) - 1] - \
                                                       v_for_simple_nodes[int(list(listofdicts_for_all_cmplx[i][k].values())[0][-1]["node1"])]) \
                                            / listofdicts_for_all_cmplx[i][k]["Z-Imaginary"]
                                                                                        
                                            v_for_simple_nodes[int(x["node2"])] = v_for_complex_nodes[int(x["node1"]) - 1] - current * x["z"]
                                            
                                # In case the component is in the middle of the branch, in a branch that consists
                                # of three components between the two complex nodes.
                                elif ((int(x["node1"]) in simple_nodes) & (int(x["node2"]) in simple_nodes)):
                                                                        
                                    z_before = complex(0, 0)
                                    the_complex_node_before = -1
                                    
                                    # Obtaining the complex node before, and the total impedance that come before the component.
                                    for y in list(listofdicts_for_all_cmplx[i][k].values())[0]:
                                        if (list(listofdicts_for_all_cmplx[i][k].values())[0].index(y) < list(listofdicts_for_all_cmplx[i][k].values())[0].index(x)):
                                            if ((y["type"] == "res") | (y["type"] == "cap") | (y["type"] == "ind")):
                                                z_before += y["z"]
                                            if(int(y["node1"]) in complex_nodes):
                                                the_complex_node_before = int(y["node1"])
                                                
                                    if ((x["type"] == "res") | (x["type"] == "cap") | (x["type"] == "ind")):
                                            z_before += x["z"]
                                    
                                    if (int(x["node2"]) not in list(v_for_simple_nodes.keys())):
                                        v_for_simple_nodes[int(x["node2"])] =  v_for_complex_nodes[the_complex_node_before - 1] - current * z_before
    

                                
                                
                                
                    else:
                        
                        current = (v_for_complex_nodes[int(list(listofdicts_for_all_cmplx[i][k].values())[0][0]["node1"]) - 1] \
                                               -  v_for_complex_nodes[int(list(listofdicts_for_all_cmplx[i][k].values())[0][-1]["node2"]) - 1]) / listofdicts_for_all_cmplx[i][k]["Z-Imaginary"]
                    
                        for x in list(listofdicts_for_all_cmplx[i][k].values())[0]:  

                            # In case the component is at the beginning of the branch.
                            if (int(x["node1"]) in complex_nodes):
                                
                                if ((x["type"] == "res") | (x["type"] == "cap") | (x["type"] == "ind")):                                    
                                    
                                    v_for_simple_nodes[int(x["node2"])] = v_for_complex_nodes[int(x["node1"]) - 1] - current * x["z"]

                            # In case the component is in the middle of the branch, in a branch that consists
                            # of three components between the two complex nodes.
                            elif ((int(x["node1"]) in simple_nodes) & (int(x["node2"]) in simple_nodes)):

                                z_before = complex(0, 0)
                                the_complex_node_before = -1
                                
                                for y in list(listofdicts_for_all_cmplx[i][k].values())[0]:
                                    
                                    if (list(listofdicts_for_all_cmplx[i][k].values())[0].index(y) < list(listofdicts_for_all_cmplx[i][k].values())[0].index(x)):
                                        
                                        if ((y["type"] == "res") | (y["type"] == "cap") | (y["type"] == "ind")):
                                            z_before += y["z"]
                                        
                                        if(int(y["node1"]) in complex_nodes):
                                            the_complex_node_before = int(y["node1"])
                                            
                                if ((x["type"] == "res") | (x["type"] == "cap") | (x["type"] == "ind")):
                                        z_before += x["z"]

                                v_for_simple_nodes[int(x["node2"])] = v_for_complex_nodes[the_complex_node_before - 1] - current * z_before


# %%
for key, value in v_for_simple_nodes.items():
    print("The voltage at node", key, "=", value)

# %%
"""
### GUI For closing window.
"""

# %%
output_layout_column = [
    [
        sg.Text("Enter the name of the file to export the results into:"),
        
    ],
    [
        sg.In(size=(150, 150), enable_events=True, key="-TEXT-"),
    ],
    [
         sg.Button('Enter'),
    ],
]
output_layout = [
    [
        sg.Column(output_layout_column),
    ]
]
window1 = sg.Window("Output file", output_layout, size=(520,100))
while True:
    event, values = window1.read()
    if event == "Exit" or event == sg.WIN_CLOSED or event == "Enter":
        outputfilename = file
        break
    if event == "-TEXT-":
        file = values["-TEXT-"]
window1.close()

# %%
"""
### Writing the results to the output file.
"""

# %%
to_be_written = ""
if complex_nodes:
    
    

    for i in range(len(v_for_complex_nodes)):
        to_be_written += "The voltage at complex node" + str(complex_nodes[i]) + " = " + str(v_for_complex_nodes[i]) + '\n'

    for key, value in v_for_simple_nodes.items():
        to_be_written += "The voltage at simple node "+ str(key) + " = "+ str(value) + '\n'
    
elif not complex_nodes:
    
    to_be_written += "There are no complex nodes."
    for key, value in v_for_simple_nodes0.items():
        to_be_written += "The voltage at simple node " + str(key) + " = " + str(value) +'.\n'
    
    to_be_written += "The voltage at the ground node " + str(ground_node) + " = 0"
    
output = open(outputfilename + ".txt", "w")
output.write(to_be_written)
output.close()

# %%
"""
### GUI For closing window
"""

# %%
last_layout_column = [
    [
        sg.Text("The results were exported into file: " + outputfilename + ".txt"),
        
    ],
    [
         sg.Button('Ok'),
    ],
]
last_layout = [
    [
        sg.Column(last_layout_column),
    ]
]
window2 = sg.Window("Output file", last_layout, size=(300,90))
while True:
    event, values = window2.read()
    if event == "Exit" or event == sg.WIN_CLOSED or event == 'Ok':
        break
window2.close()